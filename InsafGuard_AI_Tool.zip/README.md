# InsafGuard AI

Upload PDF/DOCX -> AI Simulates -> PDF Report Generated.